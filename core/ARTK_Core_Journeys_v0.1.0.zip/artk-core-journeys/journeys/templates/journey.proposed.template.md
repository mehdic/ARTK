---
id: JRN-0000
title: "<Short descriptive title>"
status: proposed
tier: release
actor: "<role>"
scope: "<area/module>"
tags: []
modules:
  foundation: []
  feature: []
links:
  requirements: []
  issues: []
  docs: []
tests: []
---

# Why this journey matters

Explain impact/risk and why it should exist in regression coverage.

# High-level flow (Declarative)

- Given ...
- When ...
- Then ...

# Open questions

List unknowns that must be clarified before implementation.
