# Changelog — artk-core-journeys

## 0.1.0 — 2025-12-23
- Initial release: Journey schema, templates, backlog/index generator + validator.
